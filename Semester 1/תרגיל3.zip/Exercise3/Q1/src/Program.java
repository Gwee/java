
public class Program {
	public static void main(String[] args) {
		Rectangle R1 = new Rectangle(5, 4);
		R1.draw('$');
		R1.readrect();
		R1.drawfilled('^');
	}
	
}
