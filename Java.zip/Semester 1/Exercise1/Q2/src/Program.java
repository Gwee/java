
public class Program {
	public static void main(String[] args) {
	Car car1 = new Car();
	car1.goFaster();
	car1.goFaster();
	car1.goFaster();
	car1.ShowSpeed();
	car1.slowDown();
	car1.ShowSpeed();
	car1.Stop();
	car1.ShowSpeed();
	}
}
