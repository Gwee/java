
public class Program {
		public static void main(String[] args) {
			Clock myClock = new Clock();
			myClock.show();
			myClock.tick();
			myClock.tick();
			myClock.tick();
			myClock.show();
			myClock.reset();
			myClock.show();
		} 
}

