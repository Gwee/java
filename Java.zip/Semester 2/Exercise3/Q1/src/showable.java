/**
 * Created by guy on 02/05/2016.
 */
public interface showable {
    public void show();
}
