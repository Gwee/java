/**
 * Created by guy on 22/05/2016.
 */
public class Program {
    public static void main(String[] args) {
        Pair <String, Integer, Double> guyPair = new Pair<String, Integer, Double>("Guy", 1985, 2.13);
        System.out.println(guyPair.toString());
    }

}
