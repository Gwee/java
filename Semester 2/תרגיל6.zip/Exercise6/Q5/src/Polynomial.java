import java.util.HashMap;
import java.util.Map;

/**
 * Created by Guy on 7/4/2016.
 */
public class Polynomial<K> {
    Map<Integer, Object> polynomial;

    public Polynomial(){
        polynomial = new HashMap<K, V>();
    }
    public  Polynomial(int numberOfMembers){
        polynomial = new HashMap<K, V>(numberOfMembers);
    }
    public void addElm(int power, int coefficient){
        if (power < 0) {
            power = Math.abs(power);
            throw new RuntimeException("ERROR: The power must be an absolute number, converting to absolute");
        }
        for (Map.Entry m : polynomial.entrySet()) {
            if ((Integer) m.getKey() == power){
                polynomial.put(power,m.getValue());
            }
        }
    }

}
