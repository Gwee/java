/**
 * Created by Guy on 4/10/2016.
 */
public abstract class PolygonShape extends TwoDimensionalShape {
    public PolygonShape(Point pos) {
        super(pos);
    }
}
