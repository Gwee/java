/**
 * Created by guy on 22/05/2016.
 */
public class DivOperationNotSupported extends RuntimeException{
    public DivOperationNotSupported(){

    }
    public DivOperationNotSupported(String message){
        super(message);
    }
}
