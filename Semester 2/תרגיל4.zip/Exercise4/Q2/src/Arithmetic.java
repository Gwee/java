/**
 * Created by guy on 20/05/2016.
 */
public interface Arithmetic {
    Object add(Object o);
    Object sub(Object o);
    Object mul(Object o);
    Object div(Object o);
}
