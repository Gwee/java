/**
 * Created by guy on 22/05/2016.
 */
public interface InputOutput {
    void read();
    void write();
}
