/**
 * Created by guy on 02/05/2016.
 */
public interface Arithmetic {
    Object add(Object o1);
    Object sub(Object o1);
    Object mul(Object o1);
    Object div(Object o1);
    Object clone();
}
