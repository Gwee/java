/**
 * Created by Guy on 5/28/2016.
 */
public class ListIndexOutOfBound extends Exception {
    public ListIndexOutOfBound(){

    }
    public ListIndexOutOfBound(String name){
        super(name);
    }
}
